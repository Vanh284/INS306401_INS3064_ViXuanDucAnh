<?php
$fruits = ["Apple", "Banana", "Pear"];

echo $fruits[1];
?>
