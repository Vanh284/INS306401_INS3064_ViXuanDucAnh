<?php
$sentence = "PHP";

$sentence .= " is";
$sentence .= " fun";

echo $sentence;
?>
