<?php
$age = 20;
$hasTicket = true;

if ($age > 18 && $hasTicket) {
    echo "Enter";
} else {
    echo "Deny";
}
?>
