<?php
$isOnline = true;

echo $isOnline ? "User is Online" : "User is Offline";
?>
