<?php
$name = "Alice";
$city = "Paris";

echo $name . " lives in " . $city . ".";
?>
