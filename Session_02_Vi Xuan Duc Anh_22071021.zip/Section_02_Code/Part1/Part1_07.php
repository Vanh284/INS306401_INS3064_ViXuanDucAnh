<?php
$a = 5;
$b = "5";

echo "Equal (" . (($a == $b) ? "True" : "False") . "), ";
echo "Identical (" . (($a === $b) ? "True" : "False") . ")";
?>
