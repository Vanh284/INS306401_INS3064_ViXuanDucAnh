<?php
$x = 10;
$y = 5;

echo ($x + $y) . ", ";
echo ($x - $y) . ", ";
echo ($x * $y) . ", ";
echo ($x / $y);
?>
