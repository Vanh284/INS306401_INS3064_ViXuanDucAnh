<?php
$scores = [60, 80, 90, 70];

$sum = array_sum($scores);
$count = count($scores);
$avg = $sum / $count;

$max = max($scores);
$min = min($scores);

$top = [];
foreach ($scores as $score) {
    if ($score > $avg) {
        $top[] = $score;
    }
}

echo "Avg: " . round($avg) . ", ";
echo "Top: [" . implode(", ", $top) . "]";
?>
