<?php
function area(float $w, float $h): float {
    return $w * $h;
}

// Test
echo area(5.5, 2);
?>
