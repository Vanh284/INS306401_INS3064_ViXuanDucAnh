<?php
function isAdult(?int $age): bool {
    if ($age === null) {
        return false;
    }
    return $age >= 18;
}

// Test
var_export(isAdult(null));
?>
