<?php
function greet(string $name): string {
    return "Hello, $name!";
}

// Test
echo greet("Sam");
?>
