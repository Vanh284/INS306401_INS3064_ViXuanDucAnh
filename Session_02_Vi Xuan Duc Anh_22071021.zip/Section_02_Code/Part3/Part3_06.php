<?php
function add(int $a, int $b): int {
    return $a + $b;
}

// Test
echo add(3, 4);
?>
