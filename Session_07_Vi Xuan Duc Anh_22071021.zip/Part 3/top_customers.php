<?php
require_once 'Database.php';

// Get connection
$db = Database::getInstance()->getConnection();

// SQL query: Top 3 customers
$sql = "SELECT u.name, u.email, SUM(o.total_amount) AS total_spent
        FROM users u
        JOIN orders o ON u.id = o.user_id
        GROUP BY u.id, u.name, u.email
        ORDER BY total_spent DESC
        LIMIT 3";

// Prepare & execute
$stmt = $db->prepare($sql);
$stmt->execute();

// Fetch data
$customers = $stmt->fetchAll();
?>

<!-- HTML Table -->
<table border="1">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Total Spent</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($customers as $row): ?>
        <tr>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['total_spent']; ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>