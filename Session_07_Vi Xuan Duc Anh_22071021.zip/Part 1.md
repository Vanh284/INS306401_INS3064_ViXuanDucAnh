# **Part 1 – Theory Warm-up (Short Answers)**

1\. JOIN Distinction: Explain the primary difference in result sets between an INNER JOIN

and a LEFT JOIN when a record in the left table has no matching record in the

right table



Answer:

\- INNER JOIN returns only matching rows from both tables.

\- LEFT JOIN returns all rows from the left table and NULL for unmatched rows from the right table.



2\. Aggregation Logic: What is the specific purpose of the HAVING clause, and why can we not use the WHERE clause for the same purpose when dealing with aggregate functions like SUM() or COUNT()?



Answer:

\- HAVING is used to filter grouped data after GROUP BY and is used with aggregate functions like SUM() and COUNT(). WHERE cannot be used because it filters rows before grouping.



3\. PDO Definition: What does PDO stand for, and name two advantages of using PDO over the older mysqli extension.



Answer:

\- PDO stands for PHP Data Objects.

\- Two advantages are: it supports multiple databases and it provides prepared statements for better security.



4\. Security: How do Prepared Statements protect a database from SQL Injection attacks? Describe the mechanism briefly.



Answer:

\- Prepared statements separate SQL code from user input. User input is treated as data, not SQL code, which prevents SQL injection attacks.



5\. Execution Flow: In a SQL query containing WHERE, GROUPBY, and HAVING, in what order does the database engine typically evaluate these clauses?



Answer: 

\- The execution order is: FROM → WHERE → GROUP BY → HAVING → SELECT → ORDER BY

