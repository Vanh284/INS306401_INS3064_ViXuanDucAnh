<?php
require_once 'Database.php';

// Khởi tạo kết nối DB
$db = Database::getInstance()->getConnection();

// Lấy danh sách Categories để hiển thị vào thẻ <select> [cite: 150]
$catStmt = $db->query("SELECT id, category_name FROM categories");
$categories = $catStmt->fetchAll();

// Lấy dữ liệu từ form (nếu có)
$searchKeyword = $_GET['search'] ?? '';
$categoryId = $_GET['category'] ?? '';

// Xây dựng câu lệnh SQL cơ bản
// SỬ DỤNG LEFT JOIN: Để lấy tên Category từ bảng categories. 
// Dùng LEFT JOIN phòng trường hợp có sản phẩm chưa được gán category (category_id = NULL) vẫn được hiển thị.
$sql = "SELECT p.id, p.name, p.price, c.category_name, p.stock 
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE 1=1";

$params = [];

// Thêm điều kiện tìm kiếm động (Dynamic Search) [cite: 149]
if (!empty($searchKeyword)) {
    $sql .= " AND p.name LIKE :search";
    // Sử dụng ký tự đại diện % cho LIKE
    $params[':search'] = '%' . $searchKeyword . '%'; 
}

// Thêm điều kiện lọc danh mục (Category Filter) [cite: 150]
if (!empty($categoryId)) {
    $sql .= " AND p.category_id = :category_id";
    $params[':category_id'] = $categoryId;
}

// PREPARED STATEMENTS: Tránh SQL Injection 
// Biến truyền vào qua mảng $params thay vì nối chuỗi trực tiếp vào SQL.
$stmt = $db->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Product Administration Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #f4f4f4; }
        /* Cảnh báo Visual Alert nếu stock < 10  */
        .low-stock { background-color: #ffcccc; color: #cc0000; font-weight: bold; }
        .filter-form { margin-bottom: 20px; }
        input, select, button { padding: 8px; margin-right: 10px; }
    </style>
</head>
<body>

    <h2>Product Administration Dashboard</h2>

    <form class="filter-form" method="GET" action="index.php">
        <input type="text" name="search" placeholder="Search by product name..." 
               value="<?php echo htmlspecialchars($searchKeyword); ?>">
        
        <select name="category">
            <option value="">-- All Categories --</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?php echo $cat['id']; ?>" 
                    <?php echo ($categoryId == $cat['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($cat['category_name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <button type="submit">Filter</button>
        <a href="index.php"><button type="button">Reset</button></a>
    </form>

    <table>
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Name</th>
                <th>Price</th>
                <th>Category Name</th>
                <th>Stock Level</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($products) > 0): ?>
                <?php foreach ($products as $product): ?>
                    <tr class="<?php echo ($product['stock'] < 10) ? 'low-stock' : ''; ?>">
                        <td><?php echo htmlspecialchars($product['id']); ?></td>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td>$<?php echo number_format($product['price'], 2); ?></td>
                        <td><?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?></td>
                        <td><?php echo htmlspecialchars($product['stock']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align:center;">No products found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>