<?php
class Database {
    private static $instance = null;
    private $connection;

    private function __construct() {
        // Bạn có thể thay đổi 'root' và '' thành username/password của bạn
        $dsn = "mysql:host=localhost;dbname=ecommerce_db;charset=utf8mb4";
        $username = "root";
        $password = "";
        
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];

        try {
            // Hoàn thiện logic kết nối PDO
            $this->connection = new PDO($dsn, $username, $password, $options);
        } catch (PDOException $e) {
            die("Lỗi kết nối cơ sở dữ liệu: " . $e->getMessage());
        }
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->connection;
    }
}
?>