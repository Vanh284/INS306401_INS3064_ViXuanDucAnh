<?php
session_start();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    if (file_exists('data/users.json')) {
        $users = json_decode(file_get_contents('data/users.json'), true);

        if (isset($users[$user]) &&
            password_verify($pass, $users[$user]['password'])) {

            $_SESSION['user'] = $user;
            header('Location: profile.php');
            exit;
        }
    }

    $error = 'Invalid username or password';
}
?>

<!DOCTYPE html>
<html>
<body>

<h2>Login</h2>

<?php if ($error): ?>
    <p style="color:red"><?= $error ?></p>
<?php endif; ?>

<form method="post">
    <input name="username" placeholder="Username" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <button>Login</button>
</form>

</body>
</html>

