<?php
session_start();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $users = json_decode(file_get_contents('data/users.json'), true);
    $user = $_POST['username'];
    $pass = $_POST['password'];

    if (isset($users[$user]) && password_verify($pass, $users[$user]['password'])) {
        $_SESSION['user'] = $user;
        header('Location: profile.php');
        exit;
    } else {
        $errors[] = 'Invalid credentials';
    }
}
?>

<!DOCTYPE html>
<html>
<body>

<h2>Login</h2>

<?php if ($errors): ?>
    <p style="color:red"><?= $errors[0] ?></p>
<?php endif; ?>

<form method="post">
    <input name="username" placeholder="Username"><br>
    <input type="password" name="password" placeholder="Password"><br>
    <button>Login</button>
</form>

</body>
</html>


