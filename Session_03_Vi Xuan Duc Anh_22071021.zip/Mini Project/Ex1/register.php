<?php
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'];
    $email = $_POST['email'];
    $pass = $_POST['password'];
    $confirm = $_POST['confirm'];

    if ($pass !== $confirm) {
        $errors[] = 'Passwords do not match';
    }

    if (empty($errors)) {
        $users = file_exists('data/users.json')
            ? json_decode(file_get_contents('data/users.json'), true)
            : [];

        $users[$user] = [
            'email' => $email,
            'password' => password_hash($pass, PASSWORD_DEFAULT),
            'bio' => '',
            'avatar' => ''
        ];

        file_put_contents(
            'data/users.json',
            json_encode($users, JSON_PRETTY_PRINT)
        );

        echo "Registration successful. <a href='login.php'>Login</a>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<body>

<h2>Register</h2>

<?php if ($errors): ?>
    <p style="color:red"><?= $errors[0] ?></p>
<?php endif; ?>

<form method="post">
    <input name="username" placeholder="Username" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <input type="password" name="confirm" placeholder="Confirm Password" required><br>
    <button>Register</button>
</form>

</body>
</html>

