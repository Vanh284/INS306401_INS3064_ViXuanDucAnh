<?php
session_start();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    if (
        !isset($_POST['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])
    ) {
        http_response_code(403);
        die("403 Forbidden");
    }


    $message = "Form submitted successfully (CSRF token valid)";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CSRF Protection</title>
</head>
<body>

<h2>CSRF Protected Form</h2>

<?php if (!empty($message)): ?>
    <p style="color:green;"><?= $message ?></p>
<?php endif; ?>

<form method="post" action="">
    <label>
        Username:
        <input type="text" name="username">
    </label>
    <br><br>


    <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

    <button type="submit">Submit</button>
</form>

</body>
</html>
