<?php
$errors = [];
$name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if ($name === '') {
        $errors['name'] = 'Name is required';
    }

    if ($email === '') {
        $errors['email'] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    }

    if (empty($errors)) {
        echo "<h2>Form submitted successfully</h2>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Error Summary Block</title>
    <style>
        .error-box {
            background: #ffe6e6;
            border: 1px solid red;
            color: #900;
            padding: 10px;
            margin-bottom: 15px;
        }
        .error {
            border: 2px solid red;
        }
    </style>
</head>
<body>

<h2>Contact Form</h2>

<?php if (!empty($errors)): ?>
    <div class="error-box">
        <strong>Please fix the following errors:</strong>
        <ul>
            <?php foreach ($errors as $err): ?>
                <li><?= htmlspecialchars($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post">

    <label>Name:</label><br>
    <input 
        type="text" 
        name="name"
        value="<?= htmlspecialchars($name) ?>"
        class="<?= isset($errors['name']) ? 'error' : '' ?>"
    ><br><br>

    <label>Email:</label><br>
    <input 
        type="text" 
        name="email"
        value="<?= htmlspecialchars($email) ?>"
        class="<?= isset($errors['email']) ? 'error' : '' ?>"
    ><br><br>

    <button type="submit">Submit</button>
</form>

</body>
</html>
