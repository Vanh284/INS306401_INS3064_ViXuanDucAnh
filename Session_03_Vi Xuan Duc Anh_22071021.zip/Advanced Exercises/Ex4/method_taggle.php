<?php
$methodUsed = $_SERVER['REQUEST_METHOD'];
$data = [];

if ($methodUsed === 'GET') {
    $data = $_GET;
} elseif ($methodUsed === 'POST') {
    $data = $_POST;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>GET vs POST Toggle</title>
    <script>
        function setMethod(method) {
            document.getElementById('testForm').method = method;
        }
    </script>
</head>
<body>

<h2>Send Data Using GET or POST</h2>

<form id="testForm" method="GET">
    <label>
        <input type="radio" name="method_choice" onclick="setMethod('GET')" checked>
        Send via GET
    </label>
    <label>
        <input type="radio" name="method_choice" onclick="setMethod('POST')">
        Send via POST
    </label>

    <br><br>

    <label>Your Message:</label><br>
    <input type="text" name="message"><br><br>

    <button type="submit">Submit</button>
</form>

<hr>

<h3>Request Method Used:</h3>
<p><?= htmlspecialchars($methodUsed) ?></p>

<h3>Received Data:</h3>
<pre>
<?php
if (!empty($data)) {
    print_r($data);
} else {
    echo 'No data received';
}
?>
</pre>

</body>
</html>
