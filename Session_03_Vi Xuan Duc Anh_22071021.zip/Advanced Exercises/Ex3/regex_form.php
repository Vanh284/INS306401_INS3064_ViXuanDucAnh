<?php
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!preg_match('/^[a-zA-Z0-9]+$/', $username)) {
        $errors[] = 'Username must contain only letters and numbers';
    }

    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = 'Password missing uppercase letter';
    }

    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = 'Password missing lowercase letter';
    }

    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = 'Password missing number';
    }

    if (!preg_match('/[\W_]/', $password)) {
        $errors[] = 'Password missing symbol';
    }

    if (empty($errors)) {
        echo "<h2>Registration Successful</h2>";
        echo "<ul>";
        echo "<li>Username: " . htmlspecialchars($username) . "</li>";
        echo "</ul>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Regex Validation Form</title>
</head>
<body>

<h2>Register</h2>

<?php
if (!empty($errors)) {
    echo "<ul style='color:red'>";
    foreach ($errors as $error) {
        echo "<li>$error</li>";
    }
    echo "</ul>";
}
?>

<form method="post">
    <label>Username:</label><br>
    <input type="text" name="username" required><br><br>

    <label>Password:</label><br>
    <input type="password" name="password" required><br><br>

    <button type="submit">Register</button>
</form>

</body>
</html>
