<?php
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    
    if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
        $message = "File upload error.";
    } else {

        $file = $_FILES['avatar'];

        
        if ($file['size'] > 2 * 1024 * 1024) {
            $message = "File size exceeds 2MB.";
        } else {

            
            $allowedTypes = ['image/jpeg', 'image/png'];

            
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime  = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);

            if (!in_array($mime, $allowedTypes)) {
                $message = "Only JPG and PNG images are allowed.";
            } else {

                
                $ext = ($mime === 'image/jpeg') ? '.jpg' : '.png';
                $newName = uniqid('avatar_', true) . $ext;

                $destination = __DIR__ . "/uploads/" . $newName;

                
                if (move_uploaded_file($file['tmp_name'], $destination)) {
                    $message = "Upload successful!<br>Saved as: $newName";
                } else {
                    $message = "Failed to move uploaded file.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Secure Avatar Upload</title>
</head>
<body>

<h2>Upload Avatar</h2>

<form method="post" enctype="multipart/form-data">
    <label>
        Choose Avatar:
        <input type="file" name="avatar" required>
    </label>
    <br><br>

    <button type="submit">Upload</button>
</form>

<br>

<?php if (!empty($message)): ?>
    <p><?= $message ?></p>
<?php endif; ?>

</body>
</html>
