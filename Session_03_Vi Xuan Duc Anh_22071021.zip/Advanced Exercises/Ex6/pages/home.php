<h2>Home Page</h2>
<p>Welcome to the home page.</p>

<nav>
    <a href="index.php?page=home">Home</a> |
    <a href="index.php?page=about">About</a> |
    <a href="index.php?page=contact">Contact</a>
</nav>
