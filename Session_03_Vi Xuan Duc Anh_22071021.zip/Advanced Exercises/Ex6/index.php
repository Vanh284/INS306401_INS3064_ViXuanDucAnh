<?php
$page = $_GET['page'] ?? 'home';

// Danh sách page được phép
$allowedPages = ['home', 'about', 'contact'];

if (!in_array($page, $allowedPages)) {
    http_response_code(404);
    echo "<h1>404 - Page Not Found</h1>";
    exit;
}

$file = __DIR__ . "/pages/$page.php";

if (!file_exists($file)) {
    http_response_code(404);
    echo "<h1>404 - Page Not Found</h1>";
    exit;
}

include $file;
