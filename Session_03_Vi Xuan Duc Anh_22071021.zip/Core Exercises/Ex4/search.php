<?php
$query = $_GET['q'] ?? "";
$safeQuery = htmlspecialchars($query, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Query Echo</title>
</head>
<body>

<h2>Search</h2>

<form method="get" action="">
    <input
        type="text"
        name="q"
        placeholder="Enter search term"
        value="<?= $safeQuery ?>"
    >
    <button type="submit">Search</button>
</form>

<?php if (!empty($query)): ?>
    <p>You searched for: <strong><?= $safeQuery ?></strong></p>
<?php endif; ?>

</body>
</html>
