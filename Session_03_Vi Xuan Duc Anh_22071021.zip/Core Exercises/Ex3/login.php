<?php
// Hardcoded credentials
$correctUser = "admin";
$correctPass = "123456";

$attempts = $_POST['attempts'] ?? 0;

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? "";
    $password = $_POST['password'] ?? "";

    if ($username === $correctUser && $password === $correctPass) {
        $message = "<p style='color:green;'>Login Successful</p>";
        $attempts = 0; // reset on success
    } else {
        $attempts++;
        $message = "<p style='color:red;'>Invalid Credentials</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Simple Login</title>
</head>
<body>

<h2>Login</h2>

<form method="post" action="">
    <label>
        Username:
        <input type="text" name="username">
    </label>
    <br><br>

    <label>
        Password:
        <input type="password" name="password">
    </label>
    <br><br>

    <!-- Hidden counter -->
    <input type="hidden" name="attempts" value="<?php echo $attempts; ?>">

    <button type="submit">Login</button>
</form>

<br>

<?php
// Display result
echo $message;

// Display failed attempts if any
if ($attempts > 0) {
    echo "<p>Failed Attempts: $attempts</p>";
}
?>

</body>
</html>
