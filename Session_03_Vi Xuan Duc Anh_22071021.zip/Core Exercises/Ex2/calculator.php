<?php
$result = "";
$error = "";

$num1 = $_POST['num1'] ?? "";
$num2 = $_POST['num2'] ?? "";
$op   = $_POST['operation'] ?? "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!is_numeric($num1) || !is_numeric($num2)) {
        $error = "Inputs must be numeric.";
    } else {
        switch ($op) {
            case '+':
                $calc = $num1 + $num2;
                break;
            case '-':
                $calc = $num1 - $num2;
                break;
            case '*':
                $calc = $num1 * $num2;
                break;
            case '/':
                if ($num2 == 0) {
                    $error = "Division by zero is not allowed.";
                } else {
                    $calc = $num1 / $num2;
                }
                break;
            default:
                $error = "Invalid operation.";
        }

        if (empty($error)) {
            $result = "$num1 $op $num2 = $calc";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Arithmetic Calculator</title>
</head>
<body>

<h2>Arithmetic Calculator</h2>

<form method="post" action="">
    <input type="text" name="num1" value="<?= $num1 ?>" placeholder="Number 1">

    <select name="operation">
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="*">*</option>
        <option value="/">/</option>
    </select>

    <input type="text" name="num2" value="<?= $num2 ?>" placeholder="Number 2">

    <br><br>
    <button type="submit">Calculate</button>
</form>

<br>

<?php
if (!empty($error)) {
    echo "<p style='color:red;'>$error</p>";
}

if (!empty($result)) {
    echo "<p style='color:green;'>$result</p>";
}
?>

</body>
</html>
