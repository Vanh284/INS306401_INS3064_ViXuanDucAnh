<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Form Submission</title>
</head>
<body>

<h2>Submitted Information</h2>

<?php
$fullName = $_POST['full_name'] ?? '';
$email    = $_POST['email'] ?? '';
$phone    = $_POST['phone'] ?? '';
$message  = $_POST['message'] ?? '';

if (empty($fullName) || empty($email) || empty($phone) || empty($message)) {
    echo "<p style='color:red;'>Missing Data</p>";
} else {
    echo "<ul>";
    echo "<li><strong>Full Name:</strong> $fullName</li>";
    echo "<li><strong>Email:</strong> $email</li>";
    echo "<li><strong>Phone Number:</strong> $phone</li>";
    echo "<li><strong>Message:</strong> $message</li>";
    echo "</ul>";
}
?>

</body>
</html>
