<?php
// Get data from Step 1
$username = $_POST['username'] ?? "";
$password = $_POST['password'] ?? "";

// Check if final submission
$isFinal = isset($_POST['bio']) && isset($_POST['location']);

function safe($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Step 2 - Profile Info</title>
</head>
<body>

<?php if ($isFinal): ?>

    <h2>Registration Complete</h2>

    <ul>
        <li><strong>Username:</strong> <?= safe($username) ?></li>
        <li><strong>Password:</strong> <?= safe($password) ?></li>
        <li><strong>Bio:</strong> <?= safe($_POST['bio']) ?></li>
        <li><strong>Location:</strong> <?= safe($_POST['location']) ?></li>
    </ul>

<?php else: ?>

    <h2>Step 2: Profile Information</h2>

    <form method="post" action="">
        <!-- Hidden fields from Step 1 -->
        <input type="hidden" name="username" value="<?= safe($username) ?>">
        <input type="hidden" name="password" value="<?= safe($password) ?>">

        <label>
            Bio:
            <textarea name="bio" required></textarea>
        </label>
        <br><br>

        <label>
            Location:
            <input type="text" name="location" required>
        </label>
        <br><br>

        <button type="submit">Finish</button>
    </form>

<?php endif; ?>

</body>
</html>
