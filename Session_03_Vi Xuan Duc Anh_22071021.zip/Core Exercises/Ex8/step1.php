<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Step 1 - Account Info</title>
</head>
<body>

<h2>Step 1: Account Information</h2>

<form method="post" action="step2.php">
    <label>
        Username:
        <input type="text" name="username" required>
    </label>
    <br><br>

    <label>
        Password:
        <input type="password" name="password" required>
    </label>
    <br><br>

    <button type="submit">Next</button>
</form>

</body>
</html>
