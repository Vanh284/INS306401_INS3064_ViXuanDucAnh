<?php
$name = "";
$email = "";
$error = "";
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name  = $_POST['name'] ?? "";
    $email = $_POST['email'] ?? "";
    $pass  = $_POST['password'] ?? "";

    if (strlen($pass) < 6) {
        $error = "Password too short";
    } else {
        $success = true;
    }
}

function safe($value) {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sticky Form</title>
</head>
<body>

<h2>Sticky Form Example</h2>

<?php if ($success): ?>

    <p style="color:green;">Form submitted successfully!</p>

<?php else: ?>

    <?php if (!empty($error)): ?>
        <p style="color:red;"><?= $error ?></p>
    <?php endif; ?>

    <form method="post" action="">
        <label>
            Name:
            <input type="text" name="name" value="<?= safe($name) ?>">
        </label>
        <br><br>

        <label>
            Email:
            <input type="email" name="email" value="<?= safe($email) ?>">
        </label>
        <br><br>

        <label>
            Password:
            <input type="password" name="password">
        </label>
        <br><br>

        <button type="submit">Submit</button>
    </form>

<?php endif; ?>

</body>
</html>
