<?php
require 'utils.php';

function showResult($label, $result) {
    echo "<p>$label: <strong>" . ($result ? "PASS" : "FAIL") . "</strong></p>";
}

echo "<h2>Testing Validation Utilities</h2>";

$raw = " <script>alert('x')</script> ";
$sanitized = sanitize($raw);
showResult("Sanitize Function", $sanitized !== $raw);

showResult("Valid Email", validateEmail("test@example.com"));
showResult("Invalid Email", !validateEmail("test@com"));

showResult("Length 5–10 (\"Hello\")", validateLength("Hello", 5, 10));
showResult("Length 5–10 (\"Hi\")", !validateLength("Hi", 5, 10));

showResult("Password Valid (Abc@1234)", validatePassword("Abc@1234"));
showResult("Password Too Short", !validatePassword("Ab@1"));
showResult("Password No Special Char", !validatePassword("Abc123456"));
