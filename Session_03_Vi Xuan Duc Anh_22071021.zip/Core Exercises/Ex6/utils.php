<?php

function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validateLength($str, $min, $max) {
    $len = strlen($str);
    return ($len >= $min && $len <= $max);
}

function validatePassword($pass) {
    if (strlen($pass) < 8) {
        return false;
    }

    if (!preg_match('/[^a-zA-Z0-9]/', $pass)) {
        return false;
    }

    return true;
}
