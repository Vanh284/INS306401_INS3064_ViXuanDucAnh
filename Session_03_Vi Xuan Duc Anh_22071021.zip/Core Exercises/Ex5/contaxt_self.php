<?php
$isSubmitted = ($_SERVER['REQUEST_METHOD'] === 'POST');

$fullName = $email = $phone = $message = "";
$error = "";
$success = false;

if ($isSubmitted) {
    $fullName = $_POST['full_name'] ?? "";
    $email    = $_POST['email'] ?? "";
    $phone    = $_POST['phone'] ?? "";
    $message  = $_POST['message'] ?? "";

    if (empty($fullName) || empty($email) || empty($phone) || empty($message)) {
        $error = "Missing Data";
    } else {
        $success = true;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Self Processing Contact Form</title>
</head>
<body>

<h2>Contact Form</h2>

<?php if ($success): ?>

    <!-- SUCCESS VIEW -->
    <h3 style="color:green;">Thank You!</h3>
    <p>Your message has been received.</p>

    <ul>
        <li><strong>Full Name:</strong> <?= $fullName ?></li>
        <li><strong>Email:</strong> <?= $email ?></li>
        <li><strong>Phone:</strong> <?= $phone ?></li>
        <li><strong>Message:</strong> <?= $message ?></li>
    </ul>

<?php else: ?>

    <!-- ERROR MESSAGE -->
    <?php
    if (!empty($error)) {
        echo "<p style='color:red;'>$error</p>";
    }
    ?>

    <!-- FORM VIEW -->
    <form method="post" action="">
        <label>
            Full Name:
            <input type="text" name="full_name" value="<?= $fullName ?>">
        </label>
        <br><br>

        <label>
            Email:
            <input type="email" name="email" value="<?= $email ?>">
        </label>
        <br><br>

        <label>
            Phone Number:
            <input type="text" name="phone" value="<?= $phone ?>">
        </label>
        <br><br>

        <label>
            Message:
            <textarea name="message"><?= $message ?></textarea>
        </label>
        <br><br>

        <button type="submit">Submit</button>
    </form>

<?php endif; ?>

</body>
</html>
